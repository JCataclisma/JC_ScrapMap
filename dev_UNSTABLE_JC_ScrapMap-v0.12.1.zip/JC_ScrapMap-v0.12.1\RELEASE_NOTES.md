# JC ScrapMap 0.12.1 — Release Notes

Português do Brasil: `RELEASE_NOTES_PORTUGUES-BR.md`

## Manual saved-player-position update

- Makes the blue saved-player-position marker clickable.
- Adds **Update saved player position** to the left sidebar after selecting the
  marker.
- Waits briefly for stable save-file and journal metadata, then makes a raw
  disposable local snapshot without opening the live source through SQLite.
- Reads only `PlayerData` from the temporary snapshot and removes it afterward.
- Updates the marker, coordinates, cell, timestamp, and status without
  rebuilding the complete map or reloading the browser page.
- Supports committed SQLite WAL data and rejects active rollback journals,
  changing files, invalid snapshots, and stale save selections.
- Keeps the previous valid position when an update fails. There are no
  automatic listeners or aggressive retries.
- Remains completely offline; all browser communication stays on localhost.

## Rescue Vehicle and Instant Recovery

- Adds exact Rescue Vehicle recognition to the existing **Vehicles** layer.
- Requires exactly two Scrap Gas Engines, seven Scrap Metal block cells, five
  Scrap Wheels, one regular Scrap Seat, and one Portable Craftbot, with no
  additional attached parts or blocks.
- Allows the required parts to be arranged in any shape or orientation.
- Displays the Rescue Vehicle with a red map symbol and the label
  **Rescue Vehicle**; regular detected vehicles remain yellow.
- Adds an expandable **Instant Recovery** control after selecting a detected
  vehicle.
- **RECOVERY AT YOUR OWN RISK!** moves every connected rigid body belonging to
  the selected vehicle to a saved reference position seven metres above the
  Rescue Vehicle.
- Preserves relative body positions, joints, bearings, suspensions,
  controllers, attached parts, and saved rotation.

## Important save-editing warning

Normal map generation and inspection remain read-only. Instant Recovery is an
explicit exception and writes directly to the selected Survival save.

Close Scrap Mechanic and back up the selected save before using recovery.
There is no automatic undo. Restore the backup if the edited world or vehicle
does not behave as expected.

Rotation is intentionally preserved. A recovered vehicle can appear or land
upside-down; the feature does not automatically level it.

## Reliability and compatibility

- Re-identifies the selected vehicle and exact Rescue Vehicle immediately
  before editing instead of trusting stale browser state.
- Applies one common translation to all connected vehicle bodies inside an
  immediate SQLite transaction.
- Updates the saved rigid-body transforms and SQLite spatial bounds together.
- Runs SQLite integrity checking before committing the edit.
- Rejects stale selections, missing vehicles, unsupported records, and saves
  without exactly one valid Rescue Vehicle.
- Keeps all existing map layers and the separate Excavation Island and
  underground views unchanged.

## Validation

- Manual hands-on player-position updating succeeded while the map remained
  open.
- Synthetic ordinary-save and WAL snapshot tests preserved the source files
  byte-for-byte and confirmed player-only UI updates without a page reload.
- Active rollback-journal snapshots were rejected while retaining the previous
  position.
- Exact signature, block-volume, and extra-part rejection tests passed.
- Multi-body translation preserved rotations, construction records, and the
  Rescue Vehicle in automated disposable-save testing.
- Python, JavaScript, launcher, map-layer regression, archive-content, and
  bundled-runtime refresh checks passed.
- Hands-on recovery testing succeeded. An upside-down landing was observed and
  accepted as expected rotation-preserving behavior.
